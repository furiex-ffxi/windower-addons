_addon.name = 'ConquestPoints'
_addon.author = 'Furiex'
_addon.version = '1.0.1'
_addon.command = 'cpt'

require('chat')
require('logger')
packets = require('packets')
json  = require('json')
files = require('files')
config = require('config')
db = require('map')
res = require('resources')
res_items = res.items
pkt = {}


valid_zones = T{"Southern San d'Oria","Northern San d'Oria","Port San d'Oria", "Windurst Woods","Bastok Markets","Port Bastok", "Bastok Mines","Lower Jeuno","Port Jeuno"}
valid_zones = {

	[235] = {npc="Rabid Wolf, I.M.", menu=32761}, -- Bastok Markets
	[234] = {npc="Crying Wind, I.M.", menu=32761}, -- Bastok Mines
	[245] = {npc="Alrauverat", menu=32763}, --Lower Jeuno
	[230] = {npc="Aravoge, T.K.",menu=32762}, --Southern Sandoria
	[241] = {npc="Harara, W.W.", menu=32759}, -- Windurst Woods
	}

defaults = {}
settings = config.load(defaults)

busy = false


windower.register_event('addon command', function(...)
    local args = T{...}
	args_length = 0
	for _ in pairs(args) do args_length = args_length + 1 end
    local cmd = args[1]
	local num_loops = args[3]
	args:remove(1)
	args:remove(2)
		
	for i,v in pairs(args) do args[i]=windower.convert_auto_trans(args[i]) end
	local item = table.concat(args," "):lower()
	local currentzone = windower.ffxi.get_info()['zone']

	if currentzone == 241 or currentzone == 234 or currentzone == 243 or currentzone == 230 or currentzone == 235 or currentzone == 256 or currentzone == 245 then 
		if cmd == 'buy' then
			if not busy then
				count_inv()
				if freeslots > 0 then
					pkt = validate(item)
					if pkt then
						busy = true
						poke_npc(pkt['Target'],pkt['Target Index'])
					else 
						windower.add_to_chat(2,"Can't find item in menu")
					end
				end	
			else
				windower.add_to_chat(2,"Still buying last item")
			end

		elseif cmd == 'buyall' then
			for i = 1, num_loops, 1 do
				did_buy = buy_all(item)
				if not did_buy then
					windower.add_to_chat(2,"STOPPING: Nothing was purchased, either packet locked or we ran out of Conquest Points.")
					return
				end
				sell_cp_items(hp_name, superwarp_command)		
			end
		else 
			windower.add_to_chat(2,"You are not currently in a zone with a Conquest Points NPC")
		end
		
	elseif cmd == 'find' then
		table.vprint(fetch_db(item))
	elseif cmd == 'selljunk' then
		junk = get_item_res('bronze cap')
		if not junk then
			print('Could not find shields')
			return
		end
		local packet = packets.new('outgoing', 0x01A, {
			["Target"]=17739805,
			["Target Index"]=29,
			["Category"]=0,
			["Param"]=0,
			["_unknown1"]=0})
		packets.inject(packet)
	elseif cmd == 'fetch' then
		table.vprint(fetch_db(item))
	end
end)


function validate(item)
	local zone = windower.ffxi.get_info()['zone']
	local me,target_index,target_id,distance
	local result = {}
	if valid_zones[zone] then
		for i,v in pairs(windower.ffxi.get_mob_array()) do
			if v['name'] == windower.ffxi.get_player().name then
				result['me'] = i
			elseif v['name'] == valid_zones[zone].npc then
				target_index = i
				target_id = v['id']
				result['Menu ID'] = valid_zones[zone].menu
				distance = windower.ffxi.get_mob_by_id(target_id).distance
			end
		end
		if math.sqrt(distance) < 6 then
			if fetch_db(item) then
				result['Target'] = target_id
				result['Option Index'] = fetch_db(item)['Option']
				result['_unknown1'] = fetch_db(item)['Index']
				result['Target Index'] = target_index
				result['Zone'] = zone 
			end
		else
		windower.add_to_chat(10,"Too far from npc")
		end
	else
	windower.add_to_chat(10,"Not in a zone with sparks npc")
	end
	if result['Zone'] == nil then result = nil end
	return result
end


function fetch_db(item)
 for i,v in pairs(db) do
  if string.lower(v.Name) == string.lower(item) then
	return v
  end
 end
end


function get_item_res(item)
    for k,v in pairs(res_items) do
        if v.en:lower() == item or v.enl:lower() == item then
            return v
        end
    end
    return nil
end


function buy_all(item)
	local currentzone = windower.ffxi.get_info()['zone']
	if currentzone == 241 then
		run_to("Harara, W.W.")
		hp_name = "Home Point #2"
		superwarp_command = "hp wind woods e"
	elseif currentzone == 230 then
		run_to("Aravoge, T.K.")
		hp_name = "Home Point #1"
		superwarp_command = "hp s san 1"
	elseif currentzone == 235 then
		run_to_xy("Rabid Wolf, I.M.", -345.66900634766, -179.42399597168)
		hp_name = "Home Point #1"
		superwarp_command = "hp bastok market e"
	elseif currentzone == 234 then
		run_to("Crying Wind, I.M.")
		hp_name = "Home Point #1"
		superwarp_command = "hp bastok mines e"	
	end
	
	count_inv()
	local current_inv = freeslots
	windower.add_to_chat(2,"You have "..freeslots.." free slots, buying "..item.. " until full") 
	local currentloop = 0
	local count_busy = 0

	while currentloop < freeslots do
		currentloop = currentloop + 1
		windower.add_to_chat(8,"Buying Item: "..item.." Loop: "..currentloop)
		if not busy then
			pkt = validate(item)
			if pkt then
				busy = true
				poke_npc(pkt['Target'],pkt['Target Index'])
			else 
				windower.add_to_chat(2,"Can't find item in menu")
			end
		else
			windower.add_to_chat(2,"Still buying last item")
			count_busy = count_busy + 1
		end

		sleepcounter = 0
		while busy and sleepcounter < 5 do
			coroutine.sleep(1)
			sleepcounter = sleepcounter + 1
			if sleepcounter == "4" then
				windower.add_to_chat(2,"Probably lost a packet, waited too long!")
			end
		end

		if count_busy >= 1 then
			windower.add_to_chat(2,"Probably not busy now, trying again...")

			-- We might be in a different menu, let's exit that
			windower.send_command('setkey escape down')
			coroutine.sleep(.1)
			windower.send_command('setkey escape up')

			busy = false
			count_busy = 0
		end
	end

	count_inv()
	if current_inv == freeslots then
		return false
	end
	return true
end


function run_to(hp_name)
    local hp = windower.ffxi.get_mob_by_name(hp_name)
    while hp and math.sqrt(hp.distance) > 5.5 do
		hp = windower.ffxi.get_mob_by_name(hp_name)
		local me = windower.ffxi.get_mob_by_target('me')
        windower.ffxi.run(hp.x - me.x, hp.y - me.y)
		coroutine.sleep(0.1)
		if (math.sqrt(hp.distance) <= 5.5) then
			windower.ffxi.run(false)
			return
		end
    end
	coroutine.sleep(0.5)
 end


 function run_to_xy(hp_name, x, y)
    local hp = windower.ffxi.get_mob_by_name(hp_name)
    while hp and math.sqrt(hp.distance) > 5.5 do
		hp = windower.ffxi.get_mob_by_name(hp_name)
		local me = windower.ffxi.get_mob_by_target('me')
        windower.ffxi.run(x - me.x, y - me.y)
		coroutine.sleep(0.2)
		if (math.sqrt(hp.distance) <= 5.5) then
			windower.ffxi.run(false)
			return
		end
    end
 end


windower.register_event('outgoing chunk',function(id,data,modified,injected,blocked)
if id == 0x05B then
	local p = packets.parse("outgoing",data)
--	print(p)
end
end)


windower.register_event('incoming chunk',function(id,data,modified,injected,blocked)
	if id == 0x034 or id == 0x032 then
	 if busy == true and pkt then
		local packet = packets.new('outgoing', 0x05B)
		packet["Target"]=pkt['Target']
		packet["Option Index"]=pkt['Option Index']
		packet["_unknown1"]=pkt['_unknown1']
		packet["Target Index"]=pkt['Target Index']
		packet["Automated Message"]=false
		packet["_unknown2"]=0
		packet["Zone"]=pkt['Zone']
		packet["Menu ID"]=pkt['Menu ID']
		packets.inject(packet)
		local packet = packets.new('outgoing', 0x016, {
		["Target Index"]=pkt['me'],
		})
		packets.inject(packet)
		busy = false
		pkt = {}
		return true
	 end
	end
	
end)


function sell_cp_items(sellnpc_hp, superwarp_command)
	local currentzone = windower.ffxi.get_info()['zone']
	-- we finished buying, walk to the home points
	run_to(sellnpc_hp)

	if currentzone == 241 then
		windower.send_command("hp 5")
		coroutine.sleep(5)
	elseif currentzone == 230 then
		windower.send_command("hp 4") 
		coroutine.sleep(5)
	elseif currentzone == 234 then
		windower.send_command("hp 3") 
		coroutine.sleep(5)	
	end

	local info = windower.ffxi.get_info()
	local zone = res.zones[info.zone].name

	-- Finished zoning, walking to Lusiane now
	windower.send_command("sellnpc \"Mercenary Captain\'s Scythe\"")
	windower.send_command("sellnpc \"Royal Squire\'s Halberd\"")
	windower.send_command("sellnpc \"Centurion\'s Axe\"")
	windower.send_command("sellnpc \"Musketeer Gun\"")

	if currentzone == 241 then
		local door = "Door:Weavers' Guild"
		run_to(door)
		local id = windower.ffxi.get_mob_by_name(door)["id"]
		local target_index = windower.ffxi.get_mob_by_name(door)["index"]
		poke_npc(id, target_index)
		sell_to_npc("Meriri", -74.43, -124.77)
		run_to(door)
		poke_npc(id, target_index )
		run_to("Home Point #5")
		coroutine.sleep(2)
		windower.send_command(superwarp_command)
		coroutine.sleep(5)
	elseif currentzone == 235 then
		run_to("Home Point #1")
		local door = "Door:Mjoll's Goods"
		run_to_xy(door, -329.60, -161.30)
		local id = windower.ffxi.get_mob_by_name(door)["id"]
		local target_index = windower.ffxi.get_mob_by_name(door)["index"]
		poke_npc(id, target_index)
		sell_to_npc("Olwyn", 0, 0)
		run_to(door)
		poke_npc(id, target_index )
		run_to("Home Point #1")
	elseif currentzone == 230 then
		sell_to_npc("Lusiane", 0, 0)
		run_to("Home Point #4")	
		coroutine.sleep(2)
		windower.send_command(superwarp_command)
		coroutine.sleep(5)	
	elseif currentzone == 234 then
		local door = "Door:Alchemists' Guild"
		run_to_xy(door, 90.64, -4.83)
		local id = windower.ffxi.get_mob_by_name(door)["id"]
		local target_index = windower.ffxi.get_mob_by_name(door)["index"]
		poke_npc(id, target_index)
		sell_to_npc("Odoba", 0, 0)
		run_to_xy(door, 92.64, -4.93)
		coroutine.sleep(1)
		poke_npc(id, target_index)
		run_to_xy("Home Point #3", 89.64, -2.73)	
		coroutine.sleep(2)
		windower.send_command(superwarp_command)
		coroutine.sleep(5)
	end
end


function poke_npc(npc,target_index)
	if npc and target_index then
		local packet = packets.new('outgoing', 0x01A, {
			["Target"]=npc,
			["Target Index"]=target_index,
			["Category"]=0,
			["Param"]=0,
			["_unknown1"]=0})
		packets.inject(packet)
	end
end


function sell_to_npc(npc_name, x, y)
	if x == 0 and y == 0 then
		run_to(npc_name)
	else
		run_to_xy(npc_name, x, y)
	end
	local npc = windower.ffxi.get_mob_by_name(npc_name)
	local p = packets.new('outgoing', 0x01A, {
		['Target'] = npc.id,
		['Target Index'] = npc.index,
	  })
	packets.inject(p)

end


function count_inv()
	local playerinv = windower.ffxi.get_items().inventory
	freeslots = playerinv.max - playerinv.count
end

--[[
]]
