	return {
		--bastok CP items--
		[16712]  = {Name = "caxe",Cost=4000,Option=32800,Index=0, Zone=235},
		[17253]  = {Name = "mgun",Cost=16000,Option=32837,Index=0, Zone=235},
		--sandy cp items
		[16844] = {Name="rshal", Cost=4000, Option=32800, Index=0, Zone=230}, --lance
		--Windy cp items
		[16776] = {Name="mscythe", Cost=4000, Option=32800, Index=0}, --lance
	}

