# ConquestPoints

Automates the purchasing of Conquest Point items. @see https://www.ffxiah.com/forum/topic/55687/converting-points-to-gil-similar-to-sparks/2/

Currently supports San D'oria and Windurst.

You must start in the zone where you will be purchasing the CP items

## Load
`//lua r ConquestPoints`

## Buy
Optionally, you can pass in the number of times you want to do the buy/sell cycle

`//cpt buyall rshal <optional_count>`  -- in Sandy

`//cpt buyall mscythe <optional_count>` --  in Windy

## Unload
`//lua u ConquestPoints`
